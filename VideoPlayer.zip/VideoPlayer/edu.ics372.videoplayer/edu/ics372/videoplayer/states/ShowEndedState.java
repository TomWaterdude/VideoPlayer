package edu.ics372.videoplayer.states;

public class ShowEndedState {

}

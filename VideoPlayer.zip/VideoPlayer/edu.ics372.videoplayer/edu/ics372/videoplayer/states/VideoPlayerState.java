package edu.ics372.videoplayer.states;

/**
 * Super class for all states
 * 
 */
public abstract class VideoPlayerState {

    /**
     * Initializes the state
     */
    public abstract void enter();

    /**
     * Performs any necessary clean up while leaving the state
     */
    public abstract void leave();

    /**
     * Process power off request
     */
    public void onPowerOffRequest() {

    }

    /**
     * Process power on request
     */
    public void onPowerOnRequest() {

    }

    /**
     * Process play request
     */
    public void onPlayRequest() {

    }

    /**
     * Process pause request
     */
    public void onPauseRequest() {

    }

    /**
     * Process fast forward request
     */
    public void onFastForwardRequest() {

    }

    /**
     * Process rewind request
     */
    public void onRewindRequest() {

    }

    /**
     * Process stop request
     */
    public void onStopRequest() {

    }

    /**
     * Process clock tick
     */
    public void onTimerTick(int timerValue) {

    }

    /**
     * Process clock ticks Generates the timer runs out event
     */
    public void onTimerRunsOut() {

    }
}

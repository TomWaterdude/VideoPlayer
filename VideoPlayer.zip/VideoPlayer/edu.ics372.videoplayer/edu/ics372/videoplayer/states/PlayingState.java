package edu.ics372.videoplayer.states;

import edu.ics372.videoplayer.timer.Notifiable;

public class PlayingState extends VideoPlayerState implements Notifiable {

    @Override
    public void enter() {
	// TODO Auto-generated method stub

    }

    @Override
    public void leave() {
	// TODO Auto-generated method stub

    }

}

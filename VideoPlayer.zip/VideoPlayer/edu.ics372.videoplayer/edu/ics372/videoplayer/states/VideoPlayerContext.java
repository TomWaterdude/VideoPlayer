package edu.ics372.videoplayer.states;

import edu.ics372.videoplayer.display.VideoPlayerDisplay;

/**
 * The context is an observer for the clock and stores the context info for
 * states
 *
 */
public class VideoPlayerContext {
    private VideoPlayerDisplay display;
    private VideoPlayerState currentState;
    private static VideoPlayerContext instance;

    /**
     * Make it a singleton
     */
    private VideoPlayerContext() {
	instance = this;
	currentState = PowerOffState.getInstance();

    }

    /**
     * Return the instance
     * 
     * @return the object
     */
    public static VideoPlayerContext getInstance() {
	if (instance == null) {
	    instance = new VideoPlayerContext();
	}
	return instance;
    }

    /**
     * The display could change. So we have to get its refrence.
     * 
     * @param display The current display object
     */
    public void setDisplay(VideoPlayerDisplay display) {
	this.display = display;
    }

    /**
     * Lets power off state be the starting state adds the object as an observable
     * for clock
     */
    public void initialize() {
	instance.changeState(PowerOffState.getInstance());
    }

    /**
     * Called from the states to change the current state
     * 
     * @param nextState the next state
     */
    public void changeState(VideoPlayerState nextState) {
	currentState.leave();
	currentState = nextState;
	currentState.enter();
    }

    /**
     * Process power off request
     */
    public void onPowerOffRequest() {
	currentState.onPowerOffRequest();
    }

    /**
     * Process power on request
     */
    public void onPowerOnRequest() {
	currentState.onPowerOnRequest();
    }

    /**
     * Process play request
     */
    public void onPlayRequest() {
	currentState.onPlayRequest();
    }

    /**
     * Process pause request
     */
    public void onPauseRequest() {
	currentState.onPauseRequest();
    }

    /**
     * Process fast forward request
     */
    public void onFastForwardRequest() {
	currentState.onFastForwardRequest();
    }

    /**
     * Process rewind request
     */
    public void onRewindRequest() {
	currentState.onRewindRequest();
    }

    /**
     * Process stop request
     */
    public void onStopRequest() {
	currentState.onStopRequest();
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     * @param time time left for cooking
     */
    public void showTimeLeft(int time) {
	display.showTimeLeft(time);
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     */
    public void showLightOn() {
	display.showLightOn();
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     */
    public void showLightOff() {
	display.showLightOff();
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     */
    public void showCooking() {
	display.showCooking();
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     */
    public void showNotCooking() {
	display.showNotCooking();
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     */
    public void showDoorOpened() {
	display.showDoorOpened();
    }

    /**
     * This invokes the right method of the display. This helps protect the states
     * from changes to the way the system utilizes the state changes.
     * 
     */
    public void showDoorClosed() {
	display.showDoorClosed();
    }

}

package edu.ics372.videoplayer.states;

import edu.ics372.videoplayer.timer.Notifiable;
import edu.ics372.videoplayer.timer.Timer;

public class FastForwardingState extends VideoPlayerState implements Notifiable {
    private static FastForwardingState instance;
    private Timer timer;

    /**
     * Private constructor for the singleton pattern
     */
    private FastForwardingState() {

    }

    /**
     * Returns the instance
     * 
     * @return this object
     */
    public static FastForwardingState getInstance() {
	if (instance == null) {
	    instance = new FastForwardingState();
	}
	return instance;
    }

    public void onPlayRequest() {
	VideoPlayerContext.getInstance().changeState(PlayingState.getInstance());
    }

    public void onStopRequest() {
	VideoPlayerContext.getInstance().changeState(StoppedState.getInstance());
    }

    @Override
    public void enter() {
	// TODO Auto-generated method stub

    }

    @Override
    public void leave() {
	// TODO Auto-generated method stub

    }

    @Override
    public void onTimerTick(int timerValue) {
	// TODO Auto-generated method stub

    }

    @Override
    public void onTimerRunsOut() {

    }

}

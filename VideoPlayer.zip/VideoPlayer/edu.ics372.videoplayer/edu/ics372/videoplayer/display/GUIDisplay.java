package edu.ics372.videoplayer.display;

import edu.ics372.videoplayer.buttons.FastForwardButton;
import edu.ics372.videoplayer.buttons.GUIButton;
import edu.ics372.videoplayer.buttons.PauseButton;
import edu.ics372.videoplayer.buttons.PlayButton;
import edu.ics372.videoplayer.buttons.PowerOffButton;
import edu.ics372.videoplayer.buttons.PowerOnButton;
import edu.ics372.videoplayer.buttons.RewindButton;
import edu.ics372.videoplayer.buttons.SelectButton;
import edu.ics372.videoplayer.buttons.StopButton;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GUIDisplay extends Application implements VideoPlayerDisplay {
    private GUIButton powerOff;
    private GUIButton powerOn;
    private GUIButton play;
    private GUIButton pause;
    private GUIButton fastForward;
    private GUIButton rewind;
    private GUIButton stop;
    private GUIButton select;

    // CHANGE SHIT HERE //
    public void start(Stage primaryStage) throws Exception {
	powerOff = new PowerOffButton("Power Off");
	powerOn = new PowerOnButton("Power On");
	play = new PlayButton("Play");
	pause = new PauseButton("Pause");
	fastForward = new FastForwardButton("Fast Forward");
	rewind = new RewindButton("Rewind");
	stop = new StopButton("Stop");
	select = new SelectButton("Select");

	GridPane pane = new GridPane();
	pane.setHgap(10);
	pane.setVgap(10);
	pane.setPadding(new Insets(10, 10, 10, 10));
	pane.add(doorStatus, 0, 0);
	pane.add(lightStatus, 1, 0);
	pane.add(timerValue, 2, 0);
	pane.add(cookingStatus, 3, 0);
	pane.add(doorCloser, 4, 0);
	pane.add(doorOpener, 5, 0);
	pane.add(cookButton, 6, 0);
	showDoorClosed();
	showLightOff();
	showTimeLeft(0);
	Scene scene = new Scene(pane);
	primaryStage.setScene(scene);
	primaryStage.setTitle("Microwave Version 2");
	MicrowaveContext.getInstance().setDisplay(this);
	primaryStage.show();
	primaryStage.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<WindowEvent>() {
	    @Override
	    public void handle(WindowEvent window) {
		System.exit(0);
	    }
	});
    }

    @Override
    public void showOff() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showNoShowSelected() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showShowSelected() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showPlaying() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showPaused() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showFastForwarding() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showRewinding() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showShowEnded() {
	// TODO Auto-generated method stub

    }

    @Override
    public void showScreenSaverOn() {
	// TODO Auto-generated method stub

    }

}

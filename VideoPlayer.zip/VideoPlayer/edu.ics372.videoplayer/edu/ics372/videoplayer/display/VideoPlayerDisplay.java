package edu.ics372.videoplayer.display;

public interface VideoPlayerDisplay {

	public void showOff();

	public void showNoShowSelected();

	public void showShowSelected();

	public void showPlaying();

	public void showPaused();

	public void showFastForwarding();

	public void showRewinding();

	public void showShowEnded();

	public void showScreenSaverOn();

}

package edu.ics372.videoplayer.buttons;

import edu.ics372.videoplayer.states.VideoPlayerContext;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class PauseButton extends GUIButton implements EventHandler<ActionEvent> {

    public PauseButton(String string) {
	super(string);
    }

    @Override
    public void handle(ActionEvent event) {
	VideoPlayerContext.getInstance().onPauseRequest();
    }

}

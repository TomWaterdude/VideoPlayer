module edu.ics372.videoplayer {
	requires javafx.controls;
	requires javafx.base;
	requires java.desktop;

	exports edu.ics372.videoplayer.display to javafx.graphics;
	exports edu.ics372.videoplayer.start to javafx.graphics;
}